import { createSlice, PayloadAction } from "@reduxjs/toolkit";

interface securitySchemes {
    securitySchemes:{}
}

const initialState: securitySchemes = {
    securitySchemes:{
        "api_key": {
          "type": "apiKey",
          "name": "api_key",
          "in": "header"
        }
      }
    }

const securitySlice = createSlice({
    name:"security",
    initialState,
    reducers: {
        securityData: (state: any, action: PayloadAction<securitySchemes>) => {
          return {
            ...state,
            securitySchemes: action.payload,
          };
        },
      },
})
export const { securityData } = securitySlice.actions;
export const selectDetails = (state: { details: securitySchemes }) =>
  state.details.securitySchemes;
export default securitySlice.reducer;